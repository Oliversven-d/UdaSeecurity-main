package com.udacity.catpoint.security.service;

import com.udacity.catpoint.image.service.ImageServiceInterface;
import com.udacity.catpoint.security.application.StatusListener;
import com.udacity.catpoint.security.data.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyFloat;
import static org.mockito.Mockito.*;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.STRICT_STUBS)
public class SecurityServiceTest
{

    public SecurityService securityService;
    private Sensor sensor;

    @Mock
    public ImageServiceInterface imageService;

    private StatusListener statusListener;

    @Mock
    public SecurityRepository securityRepository;

    static HashSet<Sensor> sensorCollection = new HashSet<>();

    Sensor tSensor = new Sensor("DOOR", SensorType.DOOR);

    static void createSensorSet() {
        Sensor doorSensor = new Sensor("DOOR", SensorType.DOOR);
        Sensor windowSensor = new Sensor("WINDOW", SensorType.WINDOW);
        Sensor motionSensor = new Sensor("MOTION", SensorType.MOTION);
        sensorCollection.add(doorSensor);
        sensorCollection.add(windowSensor);
        sensorCollection.add(motionSensor);
    }

    @BeforeEach
    public void init(){
        securityService = new SecurityService(securityRepository, imageService);
        sensor = new Sensor("sensor", SensorType.DOOR);
        securityService.addSensor(sensor);
    }


    //Tester 1
    @Test
    public void start_Pending_AlarmStatus ()
    {

        securityService.setArmingStatus(ArmingStatus.ARMED_HOME);
        Mockito.when(securityService.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
        securityService.changeSensorActivationStatus(sensor, true);
        Mockito.verify(securityRepository, Mockito.times(1)).setAlarmStatus(AlarmStatus.PENDING_ALARM);
    }
    //Tester 2
    @Test
    public void start_Set_Pending_AlarmStatus_To_Armed () { //
        Mockito.when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        Mockito.when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        tSensor.setActive(false);
        securityService.changeSensorActivationStatus(tSensor, true);
        Mockito.verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
    }
    //Tester 3
    @Test
    public void start_No_AlarmStatus () {
        Mockito.when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        Mockito.when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        tSensor.setActive(false);
        securityService.changeSensorActivationStatus(tSensor, true);
        securityService.changeSensorActivationStatus(tSensor, false);

        Mockito.verify(securityRepository, Mockito.times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
    }
    //Tester 4
    @Test
    public void AlarmState_Not_Changed_Here () {
        Mockito.when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
        tSensor.setActive(false);
        securityService.changeSensorActivationStatus(tSensor, true);
        Mockito.verify(securityRepository, Mockito.times(0)).setAlarmStatus(AlarmStatus.NO_ALARM);
        Mockito.verify(securityRepository, Mockito.times(0)).setAlarmStatus(AlarmStatus.PENDING_ALARM);
    }
    //Tester 5
    @Test
    public void sensor_Active_System_Pending_Change_To_Alarm () {
        Mockito.when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        securityService.changeSensorActivationStatus(sensor, true);
        Mockito.verify(securityRepository, Mockito.times(1)).setAlarmStatus(any(AlarmStatus.class));
    }
    //Tester 6
    @Test
    public void if_sensor_here_is_Deactivated_No_Change_here_To_AlarmState () {
        tSensor.setActive(false);
        Mockito.when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        securityService.changeSensorActivationStatus(tSensor, false);
        Mockito.verify(securityRepository, never()).setAlarmStatus(any(AlarmStatus.class));
    }
    //Tester 7
    @Test
    public void catIdentifiedWhileArmedHomeChangeSystemToAlarm () {
        securityService.setArmingStatus(ArmingStatus.ARMED_HOME);
        Mockito.when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        Mockito.when(securityService.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        securityService.processImage(mock(BufferedImage.class));
        Mockito.verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
    }
    @ParameterizedTest
    @EnumSource(ArmingStatus.class)
    public void check_if_armingStatus_run_3times(ArmingStatus armingStatus){
        securityService.setArmingStatus(armingStatus); }

    //Tester 8
    @Test
    public void check_catNotIdentifiedChangeStatusNoAlarmIfSensorsInactive () {
        Mockito.when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(false);
        tSensor.setActive(false);
        securityService.processImage(mock(BufferedImage.class));
        Mockito.verify(securityRepository, Mockito.times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
    }
    //Tester 9
    @Test
    public void if_systemDisArmedHere_ThenSetStatusNoAlarm () {
        securityService.setArmingStatus(ArmingStatus.DISARMED);
        Mockito.verify(securityRepository, Mockito.times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    @ParameterizedTest
    @EnumSource(value = ArmingStatus.class, names = {"ARMED_AWAY", "ARMED_HOME"})

    //Tester 10
    public void check_if_systemArmedResetSensorsToInactive (ArmingStatus status) {
        createSensorSet();

        sensorCollection.forEach(sensor -> sensor.setActive(true));
        Mockito.when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        Mockito.when(securityRepository.getSensors()).thenReturn(sensorCollection);
        securityService.setArmingStatus(status);
        sensorCollection.forEach(sensor -> Assertions.assertEquals(false, sensor.getActive()));
    }

    // Last Tester 11
    @Test
    public void check_if_systemArmedHomeCatIdentifiedSetStatusAlarm () {
        Mockito.when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        Mockito.when(securityService.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        securityService.processImage(mock(BufferedImage.class));
        Mockito.verify(securityRepository, Mockito.times(1)).setAlarmStatus(AlarmStatus.ALARM);
    }

    public void check_system_is_Armed_CatDetected_is_Set_To_StatusAlarm () {
        Mockito.when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        Mockito.when(securityService.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        securityService.processImage(mock(BufferedImage.class));

        securityService.setArmingStatus(securityService.getArmingStatus());
        Mockito.verify(securityRepository, times(2)).setAlarmStatus(AlarmStatus.ALARM);
    }
}

